from pathlib import Path
import json,wave,hashlib
root=Path(__file__).resolve().parent.parent/'app/src/main/assets'
story=json.loads((root/'story.json').read_text(encoding='utf-8'))
full=0
for scene in story['scenes']:
 for clip in scene['clips']+[scene['summary']]:
  path=root/clip['file']
  with wave.open(str(path),'rb')as f:
   clip['durationMs']=round(f.getnframes()/f.getframerate()*1000)
   clip['sampleRate']=f.getframerate()
   assert clip['durationMs']>100
  clip['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
 full+=sum(c['durationMs']for c in scene['clips'])
story['measuredFullDurationMs']=full
(root/'story.json').write_text(json.dumps(story,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'measuredFullDurationMs':full,'clipCount':sum(len(s['clips'])+1 for s in story['scenes'])}))
