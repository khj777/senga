import {mkdir,writeFile,readFile} from 'node:fs/promises';
const STORY=JSON.parse(await readFile(new URL('./original-story.json',import.meta.url),'utf8'));
const base=new URL('../app/src/main/assets/',import.meta.url);
await mkdir(new URL('audio/',base),{recursive:true});
const segmenter=new Intl.Segmenter('ko',{granularity:'sentence'});
const story={id:STORY.id,title:STORY.title,voice:'Microsoft Heami Desktop',audioOrigin:'Local offline speech synthesis of original story text',scenes:[]};
const lines=[];
for(let i=0;i<STORY.scenes.length;i++){
 const s=STORY.scenes[i];
 const scene={id:s.id,title:s.title,index:i,required:s.kind==='required',ending:!!s.ending,clips:[]};
 let j=0;
 for(const part of segmenter.segment(s.text)){
  const text=part.segment.trim();if(!text)continue;
  const id=`s${i+1}c${++j}`;
  scene.clips.push({id,text,file:`audio/${id}.wav`,durationMs:0});
  lines.push(id+'\t'+text);
 }
 scene.summary={id:`summary${i+1}`,text:s.shortText,file:`audio/summary${i+1}.wav`,durationMs:0};
 lines.push(scene.summary.id+'\t'+s.shortText);
 story.scenes.push(scene);
}
await writeFile(new URL('story.json',base),JSON.stringify(story,null,2));
await writeFile(new URL('../tts-input.tsv',import.meta.url),lines.join('\n'),'utf8');
console.log(`${lines.length} audio clips catalogued`);
