using System;
using System.IO;
using System.Speech.Synthesis;
using System.Text;
public class Synthesize {
    public static int Main(string[] args) {
        Directory.CreateDirectory(args[1]);
        using (var synth = new SpeechSynthesizer()) {
            synth.SelectVoice("Microsoft Heami Desktop");
            synth.Rate = -1;
            foreach (string line in File.ReadAllLines(args[0], Encoding.UTF8)) {
                int tab=line.IndexOf('\t'); if(tab<0)continue;
                string id=line.Substring(0,tab), text=line.Substring(tab+1);
                string path=Path.Combine(args[1],id+".wav");
                synth.SetOutputToWaveFile(path);
                synth.Speak(text);
                synth.SetOutputToNull();
                Console.WriteLine(id);
            }
        }
        return 0;
    }
}
