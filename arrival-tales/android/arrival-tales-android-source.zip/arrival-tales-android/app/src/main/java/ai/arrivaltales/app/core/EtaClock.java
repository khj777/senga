package ai.arrivaltales.app.core;

/** ETA uses monotonic wall time and keeps counting while audio is paused. */
public final class EtaClock {
    public static final long STALE_MS=90_000;
    private boolean vehicle,valid;
    private long sampleMs,sampledAt;
    public void manual(long ms,long now){vehicle=false;valid=true;sampleMs=Math.max(0,ms);sampledAt=now;}
    public void vehicleMode(){vehicle=true;valid=false;}
    public boolean vehicleSample(int seconds,long now) {
        if(!vehicle||seconds<0)return false;
        sampleMs=(long)seconds*1000;sampledAt=now;valid=true;return true;
    }
    public void invalidate(){valid=false;}
    public boolean isVehicle(){return vehicle;}
    public boolean isStale(long now){return vehicle&&valid&&now-sampledAt>STALE_MS;}
    public long remaining(long now){return !valid||isStale(now)?-1:Math.max(0,sampleMs-Math.max(0,now-sampledAt));}
}
