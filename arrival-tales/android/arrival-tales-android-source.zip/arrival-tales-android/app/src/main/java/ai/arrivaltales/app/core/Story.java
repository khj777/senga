package ai.arrivaltales.app.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Story {
    public final String title;
    public final List<Scene> scenes;
    public Story(String title, List<Scene> scenes) {
        this.title=title; this.scenes=Collections.unmodifiableList(new ArrayList<>(scenes));
    }
    public static final class Clip {
        public final String id, text, asset;
        public final int sceneIndex;
        public final long durationMs;
        public final boolean summary;
        public Clip(String id,String text,String asset,int sceneIndex,long durationMs,boolean summary) {
            if(durationMs<=0)throw new IllegalArgumentException("Unmeasured clip: "+id);
            this.id=id;this.text=text;this.asset=asset;this.sceneIndex=sceneIndex;this.durationMs=durationMs;this.summary=summary;
        }
    }
    public static final class Scene {
        public final String id,title;
        public final int index;
        public final boolean required,ending;
        public final List<Clip> clips;
        public final Clip summary;
        public Scene(String id,String title,int index,boolean required,boolean ending,List<Clip>clips,Clip summary) {
            this.id=id;this.title=title;this.index=index;this.required=required;this.ending=ending;
            this.clips=Collections.unmodifiableList(new ArrayList<>(clips));this.summary=summary;
        }
    }
}
