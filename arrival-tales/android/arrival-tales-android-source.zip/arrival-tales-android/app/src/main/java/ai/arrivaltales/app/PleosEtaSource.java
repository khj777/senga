package ai.arrivaltales.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import ai.pleos.playground.navi.helper.NaviHelper;
import ai.pleos.playground.navi.helper.listener.NaviHelperEventListener;
import ai.pleos.playground.navi.data.DrivingInfo;
import ai.pleos.playground.navi.data.DestinationArrivedInfo;
import kotlin.Unit;

/** Direct integration against the official NaviHelper 3.0.5 types. */
final class PleosEtaSource implements AutoCloseable {
    interface Listener {
        void state(String text);
        void eta(int seconds);
        void arrived();
        void cancelled();
    }
    private final Handler main=new Handler(Looper.getMainLooper());
    private final NaviHelper helper;
    private final Listener listener;
    private boolean closed;
    private final NaviHelperEventListener events=new NaviHelperEventListener() {
        @Override public void onDrivingInfo(DrivingInfo info) {
            if(info==null||info.getDestination()==null)return;
            int seconds=info.getDestination().getDuration();
            dispatch(()->listener.eta(seconds));
        }
        @Override public void onDestinationArrived(DestinationArrivedInfo info){dispatch(()->listener.arrived());}
        @Override public void onRouteCancelled(){dispatch(()->listener.cancelled());}
        @Override public void onReRouteEnded(){dispatch(()->listener.state("경로 재탐색 완료 · 새 시간 신호 대기"));}
        @Override public void onDestinationChanged(){dispatch(()->listener.state("목적지 변경 · 새 시간 신호 대기"));}
    };
    PleosEtaSource(Context context,Listener listener) {
        this.listener=listener;helper=new NaviHelper(context.getApplicationContext());
    }
    void connect() {
        listener.state("Pleos 내비게이션 연결 중");
        try {
            helper.initialize(()->{dispatch(()->{
                try{helper.addListener(events);listener.state("Pleos 연결됨 · 내비 경로 안내를 시작하세요");}
                catch(RuntimeException e){listener.state("내비 리스너 등록 실패: "+e.getClass().getSimpleName());}
            });return Unit.INSTANCE;},error->{dispatch(()->listener.state("Pleos 연결 실패 · 환경과 권한 확인 필요"));return Unit.INSTANCE;});
        }catch(RuntimeException e){listener.state("Pleos 사용 불가: "+e.getClass().getSimpleName());}
    }
    private void dispatch(Runnable r){main.post(()->{if(!closed)r.run();});}
    @Override public void close() {
        closed=true;
        try{helper.removeListener(events);}catch(RuntimeException ignored){}
        try{helper.release();}catch(RuntimeException ignored){}
    }
}
