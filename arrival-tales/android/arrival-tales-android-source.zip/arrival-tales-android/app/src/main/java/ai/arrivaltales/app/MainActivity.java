package ai.arrivaltales.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.MediaMetadata;
import android.media.browse.MediaBrowser;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int CREAM=Color.rgb(245,243,235),GREEN=Color.rgb(23,62,50),MUTED=Color.rgb(83,109,94);
    private MediaBrowser browser;
    private MediaController controller;
    private TextView status,eta,title,text,details,nav;
    private Button play;
    private SeekBar progress;
    private boolean playing;
    private Bundle latest=new Bundle();
    private final MediaController.Callback callback=new MediaController.Callback(){
        @Override public void onPlaybackStateChanged(PlaybackState state){render(state);}
        @Override public void onMetadataChanged(MediaMetadata data){if(data!=null)title.setText(data.getString(MediaMetadata.METADATA_KEY_TITLE));}
    };
    private int dp(float n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(CREAM);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(26),dp(20),dp(26),dp(24));scroll.addView(page);
        TextView brand=label("ARRIVAL TALES",13,MUTED);brand.setLetterSpacing(.18f);page.addView(brand);
        page.addView(label("도착동화",34,GREEN));
        TextView intro=label("길의 끝에서, 이야기의 끝까지",16,MUTED);intro.setPadding(0,0,0,dp(10));page.addView(intro);
        LinearLayout storyRow=new LinearLayout(this);storyRow.setOrientation(getResources().getConfiguration().screenWidthDp>650?LinearLayout.HORIZONTAL:LinearLayout.VERTICAL);
        boolean wide=getResources().getConfiguration().screenWidthDp>650;
        View illustration=new MoonWhale(this);storyRow.addView(illustration,new LinearLayout.LayoutParams(wide?0:LinearLayout.LayoutParams.MATCH_PARENT,dp(wide?240:155),wide?1.05f:0));
        LinearLayout storyPanel=new LinearLayout(this);storyPanel.setOrientation(LinearLayout.VERTICAL);storyPanel.setPadding(wide?dp(24):0,dp(6),0,0);
        storyRow.addView(storyPanel,new LinearLayout.LayoutParams(wide?0:LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT,wide?1:0));
        eta=label("시간 신호 대기",28,GREEN);storyPanel.addView(eta);
        title=label("달을 배달하는 고래",22,GREEN);storyPanel.addView(title);
        status=label("내비 경로 안내 또는 시연 시간을 선택하세요",15,MUTED);storyPanel.addView(status);
        text=label("작은 불빛들이 함께 만드는 귀갓길",18,GREEN);text.setLineSpacing(dp(5),1f);text.setPadding(0,dp(12),0,dp(6));storyPanel.addView(text);
        page.addView(storyRow);
        progress=new SeekBar(this);progress.setMax(1000);progress.setContentDescription("현재 문장 재생 위치");
        progress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){if(controller!=null&&controller.getMetadata()!=null)controller.getTransportControls().seekTo(controller.getMetadata().getLong(MediaMetadata.METADATA_KEY_DURATION)*s.getProgress()/1000);}
            public void onProgressChanged(SeekBar s,int n,boolean user){}
        });page.addView(progress);
        LinearLayout controls=row();
        Button reset=button("처음부터",()->command("RESET",0));controls.addView(reset,weighted());
        play=button("재생",()->{if(controller!=null){if(playing)controller.getTransportControls().pause();else controller.getTransportControls().play();}});controls.addView(play,weighted());
        controls.addView(button("다음 문장",()->{if(controller!=null)controller.getTransportControls().skipToNext();}),weighted());page.addView(controls);
        details=label("실측 음원 길이로 구성 · 안내와 도착이 우선",14,MUTED);details.setPadding(0,dp(10),0,dp(8));page.addView(details);
        nav=label("Pleos 연결 상태 확인 중",13,MUTED);page.addView(nav);
        LinearLayout sources=row();sources.addView(button("차량 내비 연결",()->command("VEHICLE",0)),weighted());sources.addView(button("개발 상태 보기",this::showAudit),weighted());page.addView(sources);
        TextView demo=label("정차 중 시연 입력 · 실제 차량 신호와 구분됩니다",13,MUTED);demo.setPadding(0,dp(14),0,dp(4));page.addView(demo);
        LinearLayout presets=row();
        presets.addView(button("여유 3:30",()->command("MANUAL_ETA",210_000)),weighted());
        presets.addView(button("단축 1:40",()->command("MANUAL_ETA",100_000)),weighted());
        presets.addView(button("곧 도착 0:45",()->command("MANUAL_ETA",45_000)),weighted());page.addView(presets);
        LinearLayout ending=row();ending.addView(button("도착",()->command("MANUAL_ETA",0)),weighted());ending.addView(button("음원과 개인정보",this::showInfo),weighted());page.addView(ending);
        TextView foot=label("주행 중 화면 조작을 피하고 차량의 미디어 제어를 사용하세요.",12,MUTED);foot.setPadding(0,dp(12),0,0);page.addView(foot);
        setContentView(scroll);
        browser=new MediaBrowser(this,new ComponentName(this,StoryService.class),new MediaBrowser.ConnectionCallback(){
            @Override public void onConnected(){
                controller=new MediaController(MainActivity.this,browser.getSessionToken());setMediaController(controller);controller.registerCallback(callback);
                callback.onMetadataChanged(controller.getMetadata());render(controller.getPlaybackState());
            }
            @Override public void onConnectionFailed(){status.setText("재생 서비스에 연결할 수 없어요");}
            @Override public void onConnectionSuspended(){status.setText("재생 서비스 연결이 끊겼어요");}
        },null);browser.connect();
    }
    private void command(String name,long milliseconds){if(controller==null)return;Bundle args=new Bundle();args.putLong("milliseconds",milliseconds);controller.sendCommand(name,args,null);}
    private TextView label(String value,int sp,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);t.setPadding(0,dp(3),0,dp(3));return t;}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);return r;}
    private LinearLayout.LayoutParams weighted(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(52),1);p.setMargins(dp(2),dp(4),dp(2),dp(4));return p;}
    private Button button(String title,Runnable action){Button b=new Button(this);b.setText(title);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(GREEN);b.setOnClickListener(v->action.run());return b;}
    private static String time(long ms){if(ms<0)return "--:--";long s=(ms+999)/1000;return String.format(Locale.ROOT,"%d:%02d",s/60,s%60);}
    private void render(PlaybackState state){
        if(state==null)return;
        playing=state.getState()==PlaybackState.STATE_PLAYING;play.setText(playing?"일시정지":"재생");
        Bundle b=state.getExtras();if(b==null)return;latest=b;
        boolean vehicle=b.getBoolean("vehicle");long remaining=b.getLong("etaMs",-1);
        eta.setText((vehicle?"차량 ":"시연 ")+time(remaining));
        status.setText(b.getString("status",""));text.setText(b.getString("text",""));
        nav.setText(b.getString("navState","")+" · 실제 ETA 수신 "+b.getInt("etaSamples")+"회");
        String mode=b.getString("mode","");String modeText="closing".equals(mode)?"짧은 결말":("focused".equals(mode)?"핵심 구성":("full".equals(mode)?"모든 모험":("complete".equals(mode)?"완주":"도착·대기")));
        details.setText(modeText+" · 예정 음원 "+time(b.getLong("planMs"))+" · 처리한 문장 "+b.getInt("completedClips")+"개");
        MediaMetadata metadata=controller==null?null:controller.getMetadata();
        long duration=metadata==null?0:metadata.getLong(MediaMetadata.METADATA_KEY_DURATION);
        progress.setProgress(duration>0?(int)Math.min(1000,state.getPosition()*1000/duration):0);
    }
    private void showAudit(){ArrayList<String>entries=latest.getStringArrayList("audit");StringBuilder s=new StringBuilder();if(entries!=null)for(String e:entries)s.append(e).append('\n');
        new AlertDialog.Builder(this).setTitle("실제 실행 상태").setMessage(s.length()==0?"아직 기록이 없어요":s.toString()).setPositiveButton("닫기",null).show();}
    private void showInfo(){new AlertDialog.Builder(this).setTitle("음원과 개인정보").setMessage("원작 동화를 PC의 한국어 음성으로 합성한 오프라인 WAV 음원입니다. 각 문장 파일의 실제 길이를 측정해 편집합니다. 실행 중 외부 AI·음성 서버를 호출하지 않습니다.\n\n아이의 음성·이름·정밀 위치를 저장하지 않습니다. 내비 API에서 목적지 잔여 시간과 경로 이벤트를 이용합니다. 최근 재생한 문장 목록은 기기 내부에 보관하며 처음부터를 누르면 초기화합니다.\n\n실제 도착이 너무 빠르면 결말 재생 중에도 도착 이벤트를 우선합니다.").setPositiveButton("확인",null).show();}
    @Override public void onDestroy(){if(controller!=null)controller.unregisterCallback(callback);if(browser!=null)browser.disconnect();super.onDestroy();}

    private static final class MoonWhale extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        MoonWhale(Activity c){super(c);setContentDescription("달씨앗을 배달하는 고래 모로");}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);float sx=getWidth()/500f,sy=getHeight()/270f;c.save();c.scale(sx,sy);
            p.setColor(Color.rgb(44,79,77));c.drawRoundRect(new RectF(0,0,500,270),22,22,p);
            p.setColor(Color.rgb(231,223,158));c.drawCircle(390,56,28,p);p.setColor(Color.rgb(44,79,77));c.drawCircle(402,48,26,p);
            p.setColor(Color.rgb(134,170,161));c.drawOval(110,116,365,225,p);
            Path tail=new Path();tail.moveTo(350,165);tail.lineTo(419,132);tail.lineTo(406,180);tail.lineTo(429,215);tail.lineTo(354,196);tail.close();c.drawPath(tail,p);
            p.setColor(Color.rgb(183,204,185));c.drawOval(121,169,323,219,p);
            p.setColor(Color.rgb(134,170,161));Path fin=new Path();fin.moveTo(230,181);fin.quadTo(282,208,301,250);fin.quadTo(242,244,214,194);fin.close();c.drawPath(fin,p);
            p.setColor(Color.rgb(22,58,50));c.drawCircle(155,160,4,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawArc(133,157,174,179,15,105,false,p);p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(218,191,128));c.drawRect(242,96,262,123,p);p.setColor(Color.rgb(240,221,153));c.drawCircle(252,86,11,p);
            p.setColor(Color.rgb(160,181,153));for(int i=0;i<12;i++)c.drawCircle(34+i*36,36+(i*19)%62,1.4f,p);
            c.restore();
        }
    }
}
