package ai.arrivaltales.app.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** All costs are measured audio milliseconds. Call at sentence boundaries. */
public final class NarrativePlanner {
    public static final class Plan {
        public final List<Story.Clip> clips;
        public final String mode;
        public final long durationMs,budgetMs;
        public final boolean overBudget;
        Plan(List<Story.Clip>clips,String mode,long budgetMs) {
            this.clips=Collections.unmodifiableList(new ArrayList<>(clips));this.mode=mode;this.budgetMs=budgetMs;
            long total=0;for(Story.Clip c:clips)total+=c.durationMs;
            durationMs=total;overBudget=total>budgetMs;
        }
    }
    public static boolean finished(Story.Scene s,Set<String>completed) {
        if(completed.contains(s.summary.id))return true;
        for(Story.Clip c:s.clips)if(!completed.contains(c.id))return false;
        return true;
    }
    public static Plan plan(Story story,Set<String>completed,int frontier,boolean closingStarted,long etaMs) {
        for(Story.Scene s:story.scenes)if(s.ending&&finished(s,completed))return new Plan(Collections.emptyList(),"complete",0);
        if(etaMs==0)return new Plan(Collections.emptyList(),"arrived",0);
        if(etaMs<0)return new Plan(Collections.emptyList(),"waiting",0);
        long reserve=Math.min(10_000,etaMs/10);
        long budget=Math.max(0,etaMs-reserve);
        List<Story.Scene>pending=new ArrayList<>(),optional=new ArrayList<>();
        long requiredMs=0;
        for(Story.Scene s:story.scenes) {
            if(s.index<frontier||finished(s,completed))continue;
            pending.add(s);
            if(s.required)requiredMs+=remaining(s,completed);
            else optional.add(s);
        }
        if(closingStarted||requiredMs>budget) {
            List<Story.Clip>closing=new ArrayList<>();
            for(Story.Scene s:pending)if(s.required&&!completed.contains(s.summary.id))closing.add(s.summary);
            // When even the short ending cannot fit, report overBudget honestly.
            // Arrival still stops playback; the app never accelerates or truncates a sentence to claim success.
            return new Plan(closing,"closing",budget);
        }
        long best=-1;int selected=0;
        for(int mask=0;mask<(1<<optional.size());mask++) {
            long cost=0;
            for(int i=0;i<optional.size();i++)if((mask&(1<<i))!=0)cost+=remaining(optional.get(i),completed);
            if(requiredMs+cost<=budget&&cost>best){best=cost;selected=mask;}
        }
        Set<Integer>chosen=new HashSet<>();
        for(int i=0;i<optional.size();i++)if((selected&(1<<i))!=0)chosen.add(optional.get(i).index);
        List<Story.Clip>result=new ArrayList<>();
        for(Story.Scene s:pending)if(s.required||chosen.contains(s.index))for(Story.Clip c:s.clips)if(!completed.contains(c.id))result.add(c);
        return new Plan(result,chosen.size()==optional.size()?"full":"focused",budget);
    }
    private static long remaining(Story.Scene s,Set<String>completed) {
        long ms=0;for(Story.Clip c:s.clips)if(!completed.contains(c.id))ms+=c.durationMs;return ms;
    }
}
