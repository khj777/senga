package ai.arrivaltales.app.core;

/** User playback intent is independent of focus ownership. */
public final class FocusGate {
    private boolean wantsPlay,hasFocus;
    public void playRequested(){wantsPlay=true;}
    public void pauseRequested(){wantsPlay=false;hasFocus=false;}
    public void granted(){hasFocus=true;}
    public void transientLoss(){hasFocus=false;}
    public void permanentLoss(){hasFocus=false;wantsPlay=false;}
    public boolean shouldPlay(){return wantsPlay&&hasFocus;}
    public boolean wantsPlay(){return wantsPlay;}
}
