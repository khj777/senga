package ai.arrivaltales.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaDescription;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.browse.MediaBrowser;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.service.media.MediaBrowserService;
import android.util.Log;
import ai.arrivaltales.app.core.EtaClock;
import ai.arrivaltales.app.core.FocusGate;
import ai.arrivaltales.app.core.NarrativePlanner;
import ai.arrivaltales.app.core.Story;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class StoryService extends MediaBrowserService {
    public static final String PLAY="ai.arrivaltales.PLAY",PAUSE="ai.arrivaltales.PAUSE",STOP="ai.arrivaltales.STOP";
    private static final String CHANNEL="arrival-story";
    private final Handler main=new Handler(Looper.getMainLooper());
    private final FocusGate gate=new FocusGate();
    private final EtaClock eta=new EtaClock();
    private final Set<String>completed=new HashSet<>();
    private final List<Story.Clip>queue=new ArrayList<>();
    private final ArrayList<String>audit=new ArrayList<>();
    private Story story;
    private Story.Clip current;
    private MediaPlayer player;
    private MediaSession session;
    private AudioManager audio;
    private AudioFocusRequest focusRequest;
    private PleosEtaSource pleos;
    private int frontier,etaSamples;
    private boolean closing,finished,foreground;
    private long lastPlanDuration;
    private String mode="waiting",status="내비 경로 안내 또는 시연 시간을 선택하세요",navState="연결 대기";
    private final AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();

    private final Runnable tick=new Runnable(){@Override public void run(){
        if(story!=null&&!finished&&eta.remaining(now())==0)arrive();
        publish();main.postDelayed(this,1000);
    }};
    private long now(){return SystemClock.elapsedRealtime();}
    private void log(String text){Log.i("ArrivalTales",text);audit.add(text);if(audit.size()>30)audit.remove(0);}

    @Override public void onCreate(){
        super.onCreate();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel(CHANNEL,"도착동화 재생",NotificationManager.IMPORTANCE_LOW));
        audio=(AudioManager)getSystemService(AUDIO_SERVICE);
        focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attributes)
            .setWillPauseWhenDucked(true).setAcceptsDelayedFocusGain(true).setOnAudioFocusChangeListener(change->{
                if(change==AudioManager.AUDIOFOCUS_GAIN){gate.granted();log("AUDIO_FOCUS_GAIN");if(gate.shouldPlay()&&!finished)continuePlaying();}
                else if(change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT||change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK){
                    gate.transientLoss();pausePlayer();status="다른 오디오를 먼저 듣고 이어갑니다";log("AUDIO_FOCUS_TRANSIENT");
                }else if(change==AudioManager.AUDIOFOCUS_LOSS){gate.permanentLoss();pausePlayer();status="오디오 사용이 종료됐어요 · 재생을 눌러 이어갈 수 있어요";log("AUDIO_FOCUS_LOSS");}
                publish();
            },main).build();
        session=new MediaSession(this,"ArrivalTales");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS|MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback(){
            @Override public void onPlay(){startForegroundService(new Intent(StoryService.this,StoryService.class).setAction(PLAY));}
            @Override public void onPause(){manualPause();}
            @Override public void onStop(){manualPause();stopForeground(true);foreground=false;stopSelf();}
            @Override public void onSkipToNext(){skipSentence();}
            @Override public void onPlayFromMediaId(String id,Bundle extras){if("whale".equals(id))onPlay();}
            @Override public void onSeekTo(long pos){if(player!=null&&current!=null){player.seekTo((int)Math.min(Math.max(0,pos),Math.max(0,current.durationMs-50)));publish();}}
            @Override public void onCommand(String command,Bundle args,ResultReceiver receiver){
                if("MANUAL_ETA".equals(command)){
                    eta.manual(Math.max(0,args.getLong("milliseconds")),now());
                    status="시연 시간 변경 · 다음 문장부터 반영";log("MANUAL_ETA "+args.getLong("milliseconds"));
                    if(eta.remaining(now())==0)arrive();else if(current==null&&!finished)replan();
                }else if("VEHICLE".equals(command)){
                    eta.vehicleMode();manualPause();status="Pleos 내비 시간 신호를 기다립니다";connectPleos();
                }else if("RESET".equals(command)){reset();}
                publish();
            }
        },main);
        session.setActive(true);setSessionToken(session.getSessionToken());
        try{
            story=StoryLoader.load(this);
            Set<String>saved=getSharedPreferences("journey",MODE_PRIVATE).getStringSet("completed",Collections.emptySet());
            completed.addAll(saved);frontier=getSharedPreferences("journey",MODE_PRIVATE).getInt("frontier",0);
            closing=getSharedPreferences("journey",MODE_PRIVATE).getBoolean("closing",false);
            for(Story.Scene s:story.scenes)if(s.ending&&NarrativePlanner.finished(s,completed))finished=true;
            eta.vehicleMode();connectPleos();
        }catch(Exception e){status="동화 파일을 불러오지 못했어요";log("ASSET_ERROR "+e.getClass().getSimpleName());}
        main.post(tick);
    }

    private void connectPleos(){
        if(pleos!=null)pleos.close();
        pleos=new PleosEtaSource(this,new PleosEtaSource.Listener(){
            @Override public void state(String value){navState=value;log("NAVI_STATE "+value);publish();}
            @Override public void eta(int seconds){
                if(!eta.vehicleSample(seconds,now()))return;
                etaSamples++;log("ETA_SAMPLE seconds="+seconds);
                if(seconds==0)arrive();else {status="차량 잔여 시간을 수신했어요 · 문장 경계에서 반영";if(current==null&&!finished)replan();}
                publish();
            }
            @Override public void arrived(){if(eta.isVehicle())arrive();}
            @Override public void cancelled(){if(eta.isVehicle()){eta.invalidate();manualPause();status="경로 안내가 취소되어 재생을 멈췄어요";log("ROUTE_CANCELLED");publish();}}
        });
        pleos.connect();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null){
            if(PLAY.equals(intent.getAction())){startForeground(101,notification());foreground=true;requestPlay();}
            else if(PAUSE.equals(intent.getAction()))manualPause();
            else if(STOP.equals(intent.getAction())){manualPause();stopForeground(true);foreground=false;stopSelf();}
        }
        return START_NOT_STICKY;
    }
    private void requestPlay(){
        if(story==null||finished){status=finished?"새 여정을 시작하려면 처음부터를 누르세요":status;publish();return;}
        if(eta.remaining(now())<0&&current==null){status="내비 경로 안내 또는 시연 시간을 먼저 선택하세요";publish();return;}
        gate.playRequested();
        int result=audio.requestAudioFocus(focusRequest);
        if(result==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){gate.granted();continuePlaying();}
        else if(result==AudioManager.AUDIOFOCUS_REQUEST_DELAYED){gate.transientLoss();status="다른 오디오가 끝나기를 기다리고 있어요";}
        else {gate.permanentLoss();status="오디오를 사용할 수 없어요 · 잠시 후 다시 시도하세요";}
        publish();
    }
    private void continuePlaying(){
        if(!gate.shouldPlay()||finished)return;
        if(player!=null){player.start();status=current.summary?"짧은 결말을 이어 듣고 있어요":"이야기를 이어 듣고 있어요";}
        else {if(!replan())return;startClip(queue.get(0));}
        publish();
    }
    private boolean replan(){
        long remaining=eta.remaining(now());
        if(remaining<0){
            queue.removeIf(c->completed.contains(c.id));
            lastPlanDuration=0;for(Story.Clip clip:queue)lastPlanDuration+=clip.durationMs;
            status="시간 신호 없음 · 기존 구성을 유지합니다";
            return !queue.isEmpty();
        }
        NarrativePlanner.Plan plan=NarrativePlanner.plan(story,completed,frontier,closing,remaining);
        queue.clear();queue.addAll(plan.clips);mode=plan.mode;lastPlanDuration=plan.durationMs;
        log("PLAN mode="+mode+" measuredMs="+plan.durationMs+" budgetMs="+plan.budgetMs);
        if("arrived".equals(mode)){arrive();return false;}
        if("complete".equals(mode)||queue.isEmpty()){finishStory();return false;}
        status=plan.overBudget?"남은 시간이 짧아요 · 결말 도중 도착하면 재생을 멈춥니다":("closing".equals(mode)?"남은 사건을 짧은 결말로 연결합니다":"측정한 음원 길이에 맞춰 구성을 정했어요");
        return true;
    }
    private void startClip(Story.Clip clip){
        if(!gate.shouldPlay())return;
        releasePlayer();current=clip;frontier=Math.max(frontier,clip.sceneIndex);
        if(clip.summary)closing=true;
        saveJourney();
        try{
            MediaPlayer next=new MediaPlayer();player=next;
            next.setAudioAttributes(attributes);
            try(AssetFileDescriptor file=getAssets().openFd(clip.asset)){next.setDataSource(file.getFileDescriptor(),file.getStartOffset(),file.getLength());}
            next.setOnCompletionListener(p->{if(p!=player)return;completeClip();});
            next.setOnErrorListener((p,what,extra)->{if(p==player){manualPause();releasePlayer();status="음원 재생 오류 · 다시 재생해 주세요";log("MEDIA_ERROR "+what+"/"+extra);publish();}return true;});
            next.prepare();
            long actual=next.getDuration();
            log("CLIP_MEASURED id="+clip.id+" expected="+clip.durationMs+" android="+actual);
            if(Math.abs(actual-clip.durationMs)>100)throw new IllegalStateException("Audio duration mismatch");
            next.start();
        }catch(Exception e){manualPause();releasePlayer();status="음원 준비 실패: "+e.getClass().getSimpleName();log("MEDIA_PREPARE_ERROR "+e.getClass().getSimpleName());}
        publish();
    }
    private void completeClip(){
        if(current==null)return;
        completed.add(current.id);queue.remove(current);log("CLIP_COMPLETE "+current.id);
        releasePlayer();current=null;saveJourney();
        if(replan()&&gate.shouldPlay())startClip(queue.get(0));
        publish();
    }
    private void skipSentence(){if(current!=null&&!finished){log("USER_SKIP "+current.id);completeClip();}}
    private boolean isPlaying(){try{return player!=null&&player.isPlaying();}catch(IllegalStateException e){return false;}}
    private void pausePlayer(){if(isPlaying())player.pause();}
    private void manualPause(){gate.pauseRequested();pausePlayer();audio.abandonAudioFocusRequest(focusRequest);status="일시정지 · 이동 시간은 계속 흐릅니다";publish();}
    private void releasePlayer(){if(player!=null){MediaPlayer old=player;player=null;old.setOnCompletionListener(null);old.setOnErrorListener(null);old.release();}}
    private void arrive(){
        if(finished)return;
        finished=true;mode="arrived";gate.pauseRequested();audio.abandonAudioFocusRequest(focusRequest);releasePlayer();current=null;queue.clear();lastPlanDuration=0;
        status="도착했어요 · 이야기를 멈추고 편안히 하차를 준비해요";log("ARRIVAL_STOP");publish();
    }
    private void finishStory(){
        finished=true;mode="complete";gate.pauseRequested();audio.abandonAudioFocusRequest(focusRequest);releasePlayer();current=null;lastPlanDuration=0;
        status="모로의 배달이 끝났어요 · 남은 길은 편안히 쉬어요";log("STORY_COMPLETE");saveJourney();publish();
    }
    private void reset(){
        manualPause();releasePlayer();current=null;completed.clear();queue.clear();frontier=0;closing=false;finished=false;lastPlanDuration=0;mode="waiting";
        if(!eta.isVehicle()&&eta.remaining(now())<=0)eta.manual(210_000,now());
        saveJourney();status="새 여정이 준비됐어요";log("USER_RESET");publish();
    }
    private void saveJourney(){getSharedPreferences("journey",MODE_PRIVATE).edit().putStringSet("completed",new HashSet<>(completed)).putInt("frontier",frontier).putBoolean("closing",closing).apply();}
    private long position(){try{return player==null?0:player.getCurrentPosition();}catch(IllegalStateException e){return 0;}}
    private Bundle stateExtras(){
        Bundle b=new Bundle();b.putString("status",status);b.putString("navState",navState);b.putString("mode",mode);b.putBoolean("vehicle",eta.isVehicle());b.putLong("etaMs",eta.remaining(now()));b.putInt("etaSamples",etaSamples);
        b.putString("text",current==null?"목적지까지 남은 시간에 맞춰, 모로의 이야기를 함께 들어요.":current.text);
        b.putLong("planMs",Math.max(0,lastPlanDuration-position()));b.putInt("remainingClips",queue.size());b.putInt("completedClips",completed.size());
        b.putBoolean("focusWaiting",gate.wantsPlay()&&!gate.shouldPlay());b.putBoolean("finished",finished);b.putStringArrayList("audit",new ArrayList<>(audit));return b;
    }
    private void publish(){
        if(session==null)return;
        int state=finished?PlaybackState.STATE_STOPPED:(isPlaying()?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED);
        Bundle extras=stateExtras();
        session.setPlaybackState(new PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_PLAY_PAUSE|PlaybackState.ACTION_STOP|PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SEEK_TO|PlaybackState.ACTION_PLAY_FROM_MEDIA_ID)
            .setState(state,position(),state==PlaybackState.STATE_PLAYING?1f:0f).setExtras(extras).build());
        session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE,current==null?"달을 배달하는 고래":story.scenes.get(current.sceneIndex).title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST,"도착동화").putString(MediaMetadata.METADATA_KEY_ALBUM,"달을 배달하는 고래")
            .putLong(MediaMetadata.METADATA_KEY_DURATION,current==null?0:current.durationMs).build());
        session.setExtras(extras);
        if(foreground)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(101,notification());
    }
    private Notification notification(){
        PendingIntent content=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        boolean playing=isPlaying();
        Intent toggle=new Intent(this,StoryService.class).setAction(playing?PAUSE:PLAY);
        PendingIntent action=PendingIntent.getForegroundService(this,1,toggle,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,2,new Intent(this,StoryService.class).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_moon).setContentTitle("도착동화 · 달을 배달하는 고래").setContentText(status).setContentIntent(content)
            .setVisibility(Notification.VISIBILITY_PUBLIC).setOnlyAlertOnce(true).setStyle(new Notification.MediaStyle().setMediaSession(session==null?null:session.getSessionToken()).setShowActionsInCompactView(0))
            .addAction(new Notification.Action.Builder(playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,playing?"일시정지":"재생",action).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"종료",stop).build()).build();
    }
    @Override public BrowserRoot onGetRoot(String packageName,int uid,Bundle hints){
        boolean own=uid==getApplicationInfo().uid;
        boolean trusted=getPackageManager().checkPermission("android.permission.MEDIA_CONTENT_CONTROL",packageName)==android.content.pm.PackageManager.PERMISSION_GRANTED;
        return own||uid==android.os.Process.SYSTEM_UID||trusted?new BrowserRoot("root",null):null;
    }
    @Override public void onLoadChildren(String parent,Result<List<MediaBrowser.MediaItem>>result){
        if(!"root".equals(parent)){result.sendResult(Collections.emptyList());return;}
        MediaDescription description=new MediaDescription.Builder().setMediaId("whale").setTitle("달을 배달하는 고래").setSubtitle("도착동화 · 남은 시간에 맞춘 오디오 동화").build();
        result.sendResult(Collections.singletonList(new MediaBrowser.MediaItem(description,MediaBrowser.MediaItem.FLAG_PLAYABLE)));
    }
    @Override public void onDestroy(){main.removeCallbacksAndMessages(null);if(pleos!=null)pleos.close();gate.pauseRequested();audio.abandonAudioFocusRequest(focusRequest);releasePlayer();if(session!=null)session.release();super.onDestroy();}
}
