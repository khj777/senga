package ai.arrivaltales.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import ai.arrivaltales.app.core.Story;

final class StoryLoader {
    static Story load(Context c)throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        try(InputStream in=c.getAssets().open("story.json")) {byte[]buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);}
        JSONObject root=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
        JSONArray data=root.getJSONArray("scenes");List<Story.Scene>scenes=new ArrayList<>();
        for(int i=0;i<data.length();i++) {
            JSONObject s=data.getJSONObject(i);JSONArray clips=s.getJSONArray("clips");List<Story.Clip>parts=new ArrayList<>();
            for(int j=0;j<clips.length();j++)parts.add(clip(clips.getJSONObject(j),i,false));
            scenes.add(new Story.Scene(s.getString("id"),s.getString("title"),i,s.getBoolean("required"),s.getBoolean("ending"),parts,clip(s.getJSONObject("summary"),i,true)));
        }
        return new Story(root.getString("title"),scenes);
    }
    private static Story.Clip clip(JSONObject o,int i,boolean shortVersion)throws Exception {
        return new Story.Clip(o.getString("id"),o.getString("text"),o.getString("file"),i,o.getLong("durationMs"),shortVersion);
    }
}
