package ai.arrivaltales.app.core;
import org.junit.Test;
import static org.junit.Assert.*;
public class FocusAndClockTest {
    @Test public void focusIsRequiredBeforePlayback(){FocusGate g=new FocusGate();g.playRequested();assertFalse(g.shouldPlay());g.granted();assertTrue(g.shouldPlay());}
    @Test public void transientLossResumesOnlyWhenUserStillWantsPlayback(){FocusGate g=new FocusGate();g.playRequested();g.granted();g.transientLoss();assertFalse(g.shouldPlay());assertTrue(g.wantsPlay());g.granted();assertTrue(g.shouldPlay());}
    @Test public void manualPauseDuringGuidanceCannotAutoResume(){FocusGate g=new FocusGate();g.playRequested();g.granted();g.transientLoss();g.pauseRequested();g.granted();assertFalse(g.shouldPlay());}
    @Test public void permanentLossClearsPlaybackIntent(){FocusGate g=new FocusGate();g.playRequested();g.granted();g.permanentLoss();g.granted();assertFalse(g.shouldPlay());}
    @Test public void manualEtaKeepsCountingWhileAudioIsPaused(){EtaClock c=new EtaClock();c.manual(120_000,1000);assertEquals(90_000,c.remaining(31_000));assertEquals(0,c.remaining(150_000));}
    @Test public void vehicleModeWaitsForActualSample(){EtaClock c=new EtaClock();c.manual(60_000,0);c.vehicleMode();assertEquals(-1,c.remaining(100));assertTrue(c.vehicleSample(40,100));assertEquals(35_000,c.remaining(5100));}
    @Test public void staleVehicleSampleStopsAutomaticTimeUse(){EtaClock c=new EtaClock();c.vehicleMode();c.vehicleSample(300,0);assertEquals(-1,c.remaining(90_001));assertTrue(c.isStale(90_001));c.vehicleSample(180,90_002);assertEquals(180_000,c.remaining(90_002));}
    @Test public void manualModeIgnoresVehicleUpdates(){EtaClock c=new EtaClock();c.manual(100_000,0);assertFalse(c.vehicleSample(1,100));assertEquals(99_900,c.remaining(100));}
    @Test public void invalidRouteCannotRetainValidEta(){EtaClock c=new EtaClock();c.vehicleMode();c.vehicleSample(60,0);c.invalidate();assertEquals(-1,c.remaining(10));}
    @Test public void negativeSignalIsRejected(){EtaClock c=new EtaClock();c.vehicleMode();assertFalse(c.vehicleSample(-5,0));assertEquals(-1,c.remaining(0));}
}
