package ai.arrivaltales.app.core;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

public class NarrativePlannerTest {
    private Story sample(){
        List<Story.Scene>scenes=new ArrayList<>();
        for(int i=0;i<8;i++){
            boolean required=i==0||i==2||i==4||i==7;
            List<Story.Clip>clips=Arrays.asList(new Story.Clip("s"+i+"a","a","a.wav",i,5000,false),new Story.Clip("s"+i+"b","b","b.wav",i,5000,false));
            scenes.add(new Story.Scene("s"+i,"scene"+i,i,required,i==7,clips,new Story.Clip("short"+i,"short","s.wav",i,2000,true)));
        }
        return new Story("test",scenes);
    }
    private Set<String>empty(){return new HashSet<>();}
    @Test public void usesMeasuredMillisAndReservesWithinEta(){
        NarrativePlanner.Plan p=NarrativePlanner.plan(sample(),empty(),0,false,100_000);
        assertEquals(80_000,p.durationMs);assertEquals("full",p.mode);assertTrue(p.durationMs<=p.budgetMs);
    }
    @Test public void removesOnlyOptionalContentWhenCoreFits(){
        Story s=sample();NarrativePlanner.Plan p=NarrativePlanner.plan(s,empty(),0,false,50_000);
        assertEquals("focused",p.mode);assertEquals(8,p.clips.size());
        for(Story.Clip c:p.clips)assertTrue(s.scenes.get(c.sceneIndex).required);
    }
    @Test public void sharpReductionChoosesCausalSummaries(){
        NarrativePlanner.Plan p=NarrativePlanner.plan(sample(),empty(),0,false,12_000);
        assertEquals("closing",p.mode);assertEquals(8000,p.durationMs);
        assertEquals(Arrays.asList("short0","short2","short4","short7"),ids(p));
    }
    @Test public void completedClipsAreNeverReplayed(){
        Set<String>done=new HashSet<>(Arrays.asList("s0a","s0b","s1a"));
        NarrativePlanner.Plan p=NarrativePlanner.plan(sample(),done,1,false,100_000);
        for(Story.Clip c:p.clips)assertFalse(done.contains(c.id));
        assertEquals("s1b",p.clips.get(0).id);
    }
    @Test public void growingEtaDoesNotRewindPastTheFrontier(){
        Set<String>done=new HashSet<>(Arrays.asList("s0a","s0b","s2a","s2b"));
        NarrativePlanner.Plan p=NarrativePlanner.plan(sample(),done,3,false,100_000);
        for(Story.Clip c:p.clips)assertTrue(c.sceneIndex>=3);
    }
    @Test public void closingStaysClosingAndDoesNotRepeatCompletedSummaries(){
        Set<String>done=new HashSet<>(Arrays.asList("short0","short2"));
        NarrativePlanner.Plan p=NarrativePlanner.plan(sample(),done,2,true,200_000);
        assertEquals("closing",p.mode);assertEquals(Arrays.asList("short4","short7"),ids(p));
    }
    @Test public void impossibleBudgetIsReportedNotFaked(){
        NarrativePlanner.Plan p=NarrativePlanner.plan(sample(),empty(),0,false,1000);
        assertTrue(p.overBudget);assertEquals(8000,p.durationMs);assertEquals("closing",p.mode);
    }
    @Test public void arrivalReturnsNoAudio(){assertTrue(NarrativePlanner.plan(sample(),empty(),0,false,0).clips.isEmpty());}
    @Test public void noEtaWaitsWithoutInventingTiming(){assertEquals("waiting",NarrativePlanner.plan(sample(),empty(),0,false,-1).mode);}
    @Test public void finalSummaryIsTerminalEvenAfterEtaGrowth(){
        assertEquals("complete",NarrativePlanner.plan(sample(),new HashSet<>(Collections.singleton("short7")),7,true,100_000).mode);
    }
    @Test public void allNormalPlansKeepOrderAndFitBudget(){
        for(long ms=45_000;ms<150_000;ms+=1000){
            NarrativePlanner.Plan p=NarrativePlanner.plan(sample(),empty(),0,false,ms);
            assertFalse(p.overBudget);int last=-1;
            for(Story.Clip c:p.clips){assertTrue(c.sceneIndex>=last);last=c.sceneIndex;}
        }
    }
    private List<String>ids(NarrativePlanner.Plan p){List<String>r=new ArrayList<>();for(Story.Clip c:p.clips)r.add(c.id);return r;}
}
