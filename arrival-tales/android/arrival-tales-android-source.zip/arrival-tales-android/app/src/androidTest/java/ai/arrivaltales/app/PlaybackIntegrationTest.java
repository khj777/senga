package ai.arrivaltales.app;

import android.app.Instrumentation;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.browse.MediaBrowser;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.runner.AndroidJUnit4;
import ai.arrivaltales.app.core.Story;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class PlaybackIntegrationTest {
    private final Instrumentation instrumentation=InstrumentationRegistry.getInstrumentation();
    private final Context context=instrumentation.getTargetContext();
    private MediaBrowser browser;
    private MediaController controller;
    private void main(Runnable r){instrumentation.runOnMainSync(r);}
    private void await(String message,BooleanSupplier condition,long timeout){
        long until=SystemClock.elapsedRealtime()+timeout;
        while(SystemClock.elapsedRealtime()<until){if(condition.getAsBoolean())return;SystemClock.sleep(100);}
        fail(message+" state="+(controller==null?"null":controller.getPlaybackState()));
    }
    private Bundle state(){PlaybackState s=controller.getPlaybackState();return s==null?new Bundle():s.getExtras();}
    private void command(String name,long value){Bundle b=new Bundle();b.putLong("milliseconds",value);controller.sendCommand(name,b,null);}
    private boolean playing(){return controller.getPlaybackState()!=null&&controller.getPlaybackState().getState()==PlaybackState.STATE_PLAYING;}
    @Test public void measuredAudioFocusBoundaryAndArrival()throws Exception{
        Story story=StoryLoader.load(context);int count=0;
        for(Story.Scene scene:story.scenes){
            java.util.List<Story.Clip>clips=new java.util.ArrayList<>(scene.clips);clips.add(scene.summary);
            for(Story.Clip clip:clips){
                MediaPlayer p=new MediaPlayer();
                try(AssetFileDescriptor fd=context.getAssets().openFd(clip.asset)){
                    p.setDataSource(fd.getFileDescriptor(),fd.getStartOffset(),fd.getLength());p.prepare();
                    assertTrue(clip.id+" duration",Math.abs(p.getDuration()-clip.durationMs)<=100);count++;
                }finally{p.release();}
            }
        }
        assertEquals(39,count);Log.i("ArrivalTest","39_ANDROID_AUDIO_DURATIONS_PASS");
        instrumentation.startActivitySync(new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        CountDownLatch connected=new CountDownLatch(1);
        main(()->{browser=new MediaBrowser(context,new ComponentName(context,StoryService.class),new MediaBrowser.ConnectionCallback(){
            @Override public void onConnected(){controller=new MediaController(context,browser.getSessionToken());connected.countDown();}
        },null);browser.connect();});
        assertTrue("MediaBrowser connection",connected.await(15,TimeUnit.SECONDS));
        AudioManager audio=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        AudioFocusRequest competing=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setOnAudioFocusChangeListener(change->{}).build();
        try{
            command("RESET",0);command("MANUAL_ETA",210000);controller.getTransportControls().play();
            await("Playback started",this::playing,10000);
            long firstEta=state().getLong("etaMs");
            assertEquals(AudioManager.AUDIOFOCUS_REQUEST_GRANTED,audio.requestAudioFocus(competing));
            await("Transient focus pauses",()->!playing()&&state().getBoolean("focusWaiting"),5000);
            SystemClock.sleep(1200);assertTrue("ETA advances while paused",state().getLong("etaMs")<firstEta);
            audio.abandonAudioFocusRequest(competing);await("Focus gain resumes",this::playing,5000);
            Log.i("ArrivalTest","REAL_AUDIO_FOCUS_PAUSE_RESUME_PASS");
            assertEquals(AudioManager.AUDIOFOCUS_REQUEST_GRANTED,audio.requestAudioFocus(competing));
            await("Second loss",()->!playing(),5000);controller.getTransportControls().pause();
            SystemClock.sleep(300);audio.abandonAudioFocusRequest(competing);SystemClock.sleep(500);
            assertFalse("Manual pause survives focus gain",playing());
            controller.getTransportControls().play();await("Resume",this::playing,5000);
            command("MANUAL_ETA",45000);
            await("Boundary closing selection",()->"closing".equals(state().getString("mode")),14000);
            Log.i("ArrivalTest","MEASURED_BOUNDARY_CLOSING_PASS");
            command("MANUAL_ETA",0);await("Arrival stops",()->state().getBoolean("finished")&&!playing(),3000);
            assertEquals("arrived",state().getString("mode"));Log.i("ArrivalTest","ARRIVAL_IMMEDIATE_STOP_PASS");
            command("RESET",0);command("VEHICLE",0);
            await("Vehicle mode",()->state().getBoolean("vehicle"),3000);
            assertEquals("No invented vehicle ETA",-1,state().getLong("etaMs"));
        }finally{
            audio.abandonAudioFocusRequest(competing);controller.getTransportControls().pause();main(()->browser.disconnect());
        }
    }
}
