package ai.arrivaltales.app;

import android.util.Log;
import android.content.Context;
import android.content.ComponentName;
import android.content.Intent;
import android.media.browse.MediaBrowser;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.runner.AndroidJUnit4;
import ai.pleos.playground.navi.helper.NaviHelper;
import ai.pleos.playground.navi.helper.listener.NaviHelperEventListener;
import ai.pleos.playground.navi.data.DrivingInfo;
import ai.pleos.playground.navi.data.RouteInfo;
import ai.pleos.playground.navi.constants.RouteOption;
import ai.pleos.playground.navi.constants.NaviErrorCode;
import kotlin.Unit;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;

/** Diagnostic route request against the real SDK; an absent ETA is NOT a passing ETA test. Emulator only. */
@RunWith(AndroidJUnit4.class)
public class NaviSdkProbe {
    @Test public void sdkConnectionAndRouteObservation()throws Exception{
        String fingerprint=android.os.Build.FINGERPRINT;
        assertTrue("Run only on the isolated emulator",fingerprint.contains("crp_avd")&&android.os.Build.MODEL.toLowerCase().contains("emulator"));
        CountDownLatch connected=new CountDownLatch(1),sample=new CountDownLatch(1);
        android.app.Instrumentation instrumentation=InstrumentationRegistry.getInstrumentation();
        Context context=instrumentation.getTargetContext();
        instrumentation.startActivitySync(new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        CountDownLatch mediaConnected=new CountDownLatch(1);
        MediaBrowser[] browser=new MediaBrowser[1];MediaController[] controller=new MediaController[1];
        instrumentation.runOnMainSync(()->{
            browser[0]=new MediaBrowser(context,new ComponentName(context,StoryService.class),new MediaBrowser.ConnectionCallback(){
                @Override public void onConnected(){controller[0]=new MediaController(context,browser[0].getSessionToken());mediaConnected.countDown();}
            },null);browser[0].connect();
        });
        assertTrue("App media session connects",mediaConnected.await(10,TimeUnit.SECONDS));
        controller[0].sendCommand("RESET",null,null);controller[0].sendCommand("VEHICLE",null,null);
        SystemClock.sleep(500);
        NaviHelper helper=new NaviHelper(context);
        NaviHelperEventListener listener=new NaviHelperEventListener(){
            @Override public void onDrivingInfo(DrivingInfo info){
                if(info.getDestination()!=null){Log.i("ArrivalProbe","SDK_DRIVING_ETA_SECONDS="+info.getDestination().getDuration());sample.countDown();}
            }
            @Override public void onRoutingCompleted(){Log.i("ArrivalProbe","SDK_ROUTING_COMPLETED");}
            @Override public void onError(NaviErrorCode code){Log.i("ArrivalProbe","SDK_ROUTE_ERROR="+code);}
        };
        try{
            helper.initialize(()->{helper.addListener(listener);connected.countDown();return Unit.INSTANCE;},error->{Log.e("ArrivalProbe","SDK_CONNECT_ERROR",error);return Unit.INSTANCE;});
            assertTrue("SDK connects",connected.await(15,TimeUnit.SECONDS));
            Log.i("ArrivalProbe","SDK_CONNECTION_CONFIRMED");
            helper.requestRoute(new RouteInfo(37.48544722,127.03636666,null,null,"42dot","36khp37hh8gqcm5nqhe5","서울시 강남구 남부순환로 2621","0",RouteOption.RECOMMENDED,"",false));
            boolean received=sample.await(30,TimeUnit.SECONDS);
            Log.i("ArrivalProbe",received?"SDK_ETA_RECEIVED":"SDK_ETA_NOT_VERIFIED_NO_DRIVING_SAMPLE");
            assertTrue("Official emulator must deliver an ETA for this integration check",received);
            long until=SystemClock.elapsedRealtime()+5000;
            while(controller[0].getExtras().getInt("etaSamples")==0&&SystemClock.elapsedRealtime()<until)SystemClock.sleep(100);
            assertTrue("App receives official ETA",controller[0].getExtras().getInt("etaSamples")>0);
            assertTrue("App remains in vehicle mode",controller[0].getExtras().getBoolean("vehicle"));
            controller[0].getTransportControls().play();SystemClock.sleep(1500);
            assertEquals("SDK ETA drives actual audio",PlaybackState.STATE_PLAYING,controller[0].getPlaybackState().getState());
            Log.i("ArrivalProbe","APP_VEHICLE_ETA_TO_NATIVE_AUDIO_PASS");
            android.graphics.Bitmap screenshot=instrumentation.getUiAutomation().takeScreenshot();
            try(java.io.FileOutputStream output=new java.io.FileOutputStream(new java.io.File(context.getFilesDir(),"sdk-eta.png"))){screenshot.compress(android.graphics.Bitmap.CompressFormat.PNG,100,output);}
        }finally{
            controller[0].getTransportControls().pause();
            try{helper.cancelRoute();}catch(RuntimeException ignored){}
            helper.removeListener(listener);helper.release();
            instrumentation.runOnMainSync(()->browser[0].disconnect());
        }
    }
}
