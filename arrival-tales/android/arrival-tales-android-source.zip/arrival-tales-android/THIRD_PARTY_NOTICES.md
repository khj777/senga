# 의존성과 제작 출처

Android API와 SDK, Gradle 및 Android Gradle Plugin은 해당 공급자의 라이선스와 조건에 따릅니다. Gradle wrapper는 Gradle 배포 도구의 일부이며 Apache License 2.0에 따라 제공됩니다. NaviHelper SDK와 Pleos 에뮬레이터는 Pleos/42dot 조건에 따르며 이 소스 압축에 SDK 바이너리나 시스템 이미지를 재배포하지 않습니다. 빌드 시 공식 저장소에서 가져옵니다.

직접 의존성은 NaviHelper 3.0.5입니다. 테스트에는 JUnit 4.13.2(Eclipse Public License 1.0), AndroidX Test Runner 1.6.2(Apache License 2.0)를 사용합니다. 전이 의존성은 Gradle의 `:app:dependencies`로 확인할 수 있습니다. 각 라이브러리의 NOTICE 및 라이선스가 우선합니다.

원문은 이 프로젝트를 위해 작성한 「달을 배달하는 고래」이며 코드·원문·벡터 도형 일러스트 작성에 생성형 AI의 도움을 받았습니다. WAV는 Microsoft Heami Desktop 음성으로 이 원문을 로컬 합성한 결과물입니다. 합성 엔진이나 Microsoft 음성 모델은 포함하지 않습니다.

저장소 공개는 프로젝트 원문·코드에 대한 별도 오픈소스 라이선스 부여를 의미하지 않습니다. 외부 출판물·음원은 사용하지 않았습니다.
